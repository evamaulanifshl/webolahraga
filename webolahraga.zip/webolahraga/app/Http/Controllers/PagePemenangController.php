<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pemenang;
use App\Models\Event;
use App\Models\Anggota;

class PagePemenangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Pemenang::with('event','anggota')->get();
        return view('page/pemenang/index', ['pemenang'=>$data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $event = Event::all();
        $anggota = Anggota::all();
        return view('page.pemenang.create', compact('event','anggota'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       Pemenang::create([
            'event_id' => $request->event_id,
            'anggota_id' => $request->anggota_id,
            'posisi' => $request->posisi, // Tambahkan field ini
            ]);

            return redirect()->route('pemenang.index')->with('success', 'Data successfully saved.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pemenang =Pemenang::find($id);
        $event= Event::all();
        $anggota = Anggota::all();


        return view('page.pemenang.edit', compact('pemenang','event','anggota'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $pemenang = Pemenang::find($id);
        $pemenang->event_id = $request->event_id;
        $pemenang->anggota_id = $request->anggota_id;
        $pemenang->posisi = $request->posisi;

        $pemenang->save();
        return redirect()->route('pemenang.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pemenang = Pemenang::find($id);
        $pemenang->delete();
        return redirect()->route('pemenang.index');
    }
}
