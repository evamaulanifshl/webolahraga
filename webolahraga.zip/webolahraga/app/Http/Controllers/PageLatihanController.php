<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Latihan;
use App\Models\Anggota;
use App\Models\Jenis;

class PageLatihanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Latihan::with('anggota','jenis')->get();
        return view('page/latihan/index', ['latihan'=>$data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $anggota = Anggota::all();
        $jenis = Jenis::all();
        return view('page.latihan.create', compact('anggota','jenis'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Latihan::create([
            'anggota_id' => $request->anggota_id,
            'jenis_id' => $request->jenis_id,
            'tanggal' => $request->tanggal, // Tambahkan field ini
            'durasi' => $request->durasi, // Tambahkan field ini juga
            ]);

            return redirect()->route('latihan.index')->with('success', 'Data successfully saved.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $latihan =Latihan::find($id);
        $anggota = Anggota::all();
        $jenis = Jenis::all();

        return view('page.latihan.edit', compact('latihan','anggota','jenis'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $latihan = Latihan::find($id);
        $latihan->anggota_id = $request->anggota_id;
        $latihan->jenis_id = $request->jenis_id;
        $latihan->tanggal = $request->tanggal;
        $latihan->durasi = $request->durasi;

        $latihan->save();
        return redirect()->route('latihan.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $latihan = Latihan::find($id);
        $latihan->delete();
        return redirect()->route('latihan.index');
    }
}
