<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pelatih;
use RealRashid\SweetAlert\Facades\Alert;

class PagePelatihController extends Controller
{
    public function index()
    {
        $data = Pelatih::all();
        return view('page.pelatih.index', compact('data'));
    }

    public function create()
    {
        return view('page.pelatih.create');
    }

    public function store(Request $request)
    {
        try {
            Pelatih::create($request->all());
            Alert::success('Berhasil', 'Pelatih berhasil ditambahkan!');
        } catch (\Exception $e) {
            Alert::error('Gagal', 'Terjadi kesalahan saat menambah pelatih.');
        }

        return redirect()->route('pelatih.index');
    }

    public function edit($id)
    {
        $pelatih = Pelatih::findOrFail($id);
        return view('page.pelatih.edit', compact('pelatih'));
    }

    public function update(Request $request, $id)
    {
        try {
            $pelatih = Pelatih::find($id);
            $pelatih->update($request->all());
            Alert::success('Berhasil', 'Data pelatih berhasil diupdate!');
        } catch (\Exception $e) {
            Alert::error('Gagal', 'Terjadi kesalahan saat mengupdate data.');
        }

        return redirect()->route('pelatih.index');
    }

    public function destroy($id)
    {
        try {
            $pelatih = Pelatih::findOrFail($id);
            $pelatih->delete();
            Alert::success('Berhasil', 'Pelatih berhasil dihapus!');
        } catch (\Exception $e) {
            Alert::error('Gagal', 'Terjadi kesalahan saat menghapus pelatih.');
        }

        return redirect()->route('pelatih.index');
    }
}
