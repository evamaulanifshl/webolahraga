@extends('template')
@section('content')
<br><br><br>
@if(auth()->check())
    <div class="alert alert-success">
        Halo {{ auth()->user()->name }} Selamat datang di halaman admin!!
    </div>
@else
    <div class="alert alert-warning">User is not authenticated</div>
@endif
<br>
    {{-- <div class="row">
      <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats" style="background-color: #f5f5ec;">
          <div class="card-body" >
            <div class="row" >
              <div class="col-5 col-md-4">
                <div class="icon-big text-center icon-warning">
                  <i class="fa fa-leaf" style="color: #59f159;"></i>
                </div>
              </div>
              <div class="col-8 col-md-8">
                <div class="numbers">
                  <p class="card-category" style="color: #808080;"><br>Tanaman</p>
                </div>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <hr>
            <div class="stats">
                <a href="/admin/tanaman" style="color: #808080;">
              <i class="fa fa-refresh"></i> Tanaman</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats" style="background-color: #f5f5ec;">
          <div class="card-body">
            <div class="row">
              <div class="col-5 col-md-4">
                <div class="icon-big text-center icon-warning">
                  <i class="fa fa-tags" style="color: #FF6347;"></i>
                </div>
              </div>
              <div class="col-7 col-md-8">
                <div class="numbers">
                  <p class="card-category" style="color: #808080;"><br>Kategori</p>
                </div>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <hr>
            <div class="stats">
                <a href="/admin/kategori" style="color: #808080;">
              <i class="fa fa-refresh"></i> Kategori</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats" style="background-color: #f5f5ec;">
          <div class="card-body">
            <div class="row">
              <div class="col-5 col-md-4">
                <div class="icon-big text-center icon-warning">
                  <i class="fa fa-shopping-cart" style="color: #FFA500;"></i>
                </div>
              </div>
              <div class="col-7 col-md-8">
                <div class="numbers">
                  <p class="card-category" style="color: #808080;"><br>Transaksi</p>
                </div>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <hr>
            <div class="stats">
                <a href="/admin/transaksi" style="color: #808080;">
              <i class="fa fa-refresh"></i> Transaksi</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats" style="background-color: #f5f5ec;">
          <div class="card-body">
            <div class="row">
              <div class="col-5 col-md-4">
                <div class="icon-big text-center icon-warning">
                  <i class="fa fa-user" style="color: #7fd2ee;"></i>
                </div>
              </div>
              <div class="col-7 col-md-8">
                <div class="numbers">
                  <p class="card-category" style="color: #808080;"><br>User Profile</p>
                </div>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <hr>
            <div class="stats">
                <a href="/admin/user" style="color: #808080;">
              <i class="fa fa-refresh"></i> User Profile</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Section Users Behavior with an added image -->
    <div class="row">
      <div class="col-md-12">
        <div class="card " style="background-color: #f5f5ec;">
          <div class="card-header">
            <h5 class="card-title">Hydroponics</h5>
            <p class="card-category">Type of horticulture</p>
          </div>
          <div class="card-body" style="padding: 0;"> <!-- Menghapus padding dari card-body -->
            <img src="{{ asset('vendor/assets/img/p.jpg') }}" alt="Hydroponics" style="width: 100%; height: 100%; object-fit: cover; display: block; opacity: 0.8;">
        </div>
          <div class="card-footer">
            <hr>
            <div class="stats">
              {{-- <i class="fa fa-history"></i> Updated 3 minutes ago --}}
            </div>
          </div>
        </div>
      </div>
    </div> --}}
@endsection
