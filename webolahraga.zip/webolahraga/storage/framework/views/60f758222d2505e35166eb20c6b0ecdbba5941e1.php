<?php $__env->startSection('content'); ?>
<br><br><br>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h2 class="mb-0">Data Latihan</h2>
        </div>
        <div class="card-body">
            <!-- Tombol tambah data -->
            <a href="<?php echo e(route('latihan.create')); ?>" class="btn btn-primary mb-3">
                <i class="fa fa-plus"></i> Tambah Data
            </a>
            <!-- Table -->
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Anggota</th>
                            <th>Jenis Olahraga</th>
                            <th>Tanggal</th>
                            <th>Durasi</th>
                            <th colspan="2">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1 ?>
                        <?php $__currentLoopData = $latihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($isi->anggota->anggota); ?></td>
                            <td><?php echo e($isi->jenis->jenis); ?></td>
                            <td><?php echo e($isi->tanggal); ?></td>
                            <td><?php echo e($isi->durasi); ?></td>
                            <td>
                                <a href="<?php echo e(route('latihan.edit', $isi->id)); ?>"><i class="fas fa-edit"></i></a> <!-- Edit -->
                                <form action="<?php echo e(route('latihan.destroy', $isi->id)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" style="background: none; border: none; color: red; cursor: pointer;">
                                    <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Initialize DataTables -->
<script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            "paging": true,
            "searching": true,
            "info": true,
            "language": {
                "search": "Cari:",
                "paginate": {
                    "previous": "Sebelumnya",
                    "next": "Selanjutnya"
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webolahraga\resources\views/page/latihan/index.blade.php ENDPATH**/ ?>