<?php $__env->startSection('content'); ?>
<br><br><br>
<?php if(auth()->check()): ?>
    <div class="alert alert-success">
        Halo <?php echo e(auth()->user()->name); ?> Selamat datang di halaman admin!!
    </div>
<?php else: ?>
    <div class="alert alert-warning">User is not authenticated</div>
<?php endif; ?>
<br>
    
            </div>
          </div>
        </div>
      </div>
    </div> --}}
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webolahraga\resources\views/dashboard.blade.php ENDPATH**/ ?>