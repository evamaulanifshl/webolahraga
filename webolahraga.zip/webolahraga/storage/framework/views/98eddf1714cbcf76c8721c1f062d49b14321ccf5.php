<?php $__env->startSection('content'); ?>
<br><br><br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0">Tambah Pemenang Event</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('pemenang.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        Nama Event : <select name="event_id" id="event_id">
                            <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($isi->id); ?>"><?php echo e($isi->event); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select><br>

                        Nama Anggota : <select name="anggota_id" id="anggota_id">
                            <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($isi->id); ?>"><?php echo e($isi->anggota); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select><br>

                        <div class="mb-3">
                            <label for="posisi" class="form-label">Posisi</label>
                            <input type="text" id="posisi" name="posisi" class="form-control" required>
                        </div>
                        <div class="d-flex">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-save"></i> Simpan
                            </button>
                            <a href="<?php echo e(route('pemenang.index')); ?>" class="btn btn-danger">
                                <i class="fas fa-arrow-left"></i> Kembali
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webolahraga\resources\views/page/pemenang/create.blade.php ENDPATH**/ ?>