<?php

use App\Http\Controllers\PageAnggotaController;
use App\Http\Controllers\PageJenisController;
use App\Http\Controllers\PageLatihanController;
use App\Http\Controllers\PagePelatihController;
use App\Http\Controllers\PageEventController;
use App\Http\Controllers\PagePemenangController;
use App\Http\Controllers\PageJadwalController;
use App\Http\Controllers\Dashboard;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('dashboard', [Dashboard::class, 'dashboard']);
Route::resource('/anggota', PageAnggotaController::class);
Route::resource('/jenisolahraga', PageJenisController::class);
Route::resource('/latihan', PageLatihanController::class);
Route::resource('/pelatih', PagePelatihController::class);
Route::resource('/event', PageEventController::class);
Route::resource('/pemenang', PagePemenangController::class);
Route::resource('/jadwal', PageJadwalController::class);
